// src/brand-profile.ts
var PROFILE_DATA = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAyAAAAMgCAYAAADbcAZoAAAbZElEQVR4nO3asbElZxWF0SEEYsDGwiMB8PFJAReXsHAwMJQAmSBhw/yl6ppSCUlzZt7b5+7utYyu7gzud/f51a9/87v/fgAAAAgQIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0Co9q9v/v7xCQBc/vHPbz785a9/+/gGr0mAUE2AAMAn3373nw9//NOfP/z72+8+fsFrEiBUEyAA8MlZPs4CAq9MgFBNgADA9054nACBVydAqCZAAMDpFV0ECNUECAA4vaKLAKGaAAHg6U54nACBFgKEagIEgCdzekUjAUI1AQLAk53l4ywg0ESAUE2AAPBUJzxOgEAbAUI1AQLAEzm9opkAoZoAAeCJzvJxFhBoJECoJkAAeJoTHidAoJUAoZoAAeBJnF5xBwKEagIEgCc5y8dZQKCZAKGaAAHgKU54nACBdgKEagIEgCdwesWdCBCqCRAAnuAsH2cBgTsQIFQTIADc3QmPEyBwFwKEagIEgDtzesUdCRCqCRAA7uwsH2cBgTsRIFQTIADc1QmPEyBwNwKEagIEgDtyesWdCRCqCRAA7ugsH2cBgTsSIFQTIADczQmPEyBwVwKEagIEgDtxesUTCBCqCRAA7uQsH2cBgTsTIFQTIADcxQmPEyBwdwKEagIEgDtwesWTCBCqCRAA7uAsH2cBgScQIFQTIAC0O+FxAgSeQoBQTYAA0MzpFU8kQKgmQABodpaPs4DAkwgQqgkQAFqd8DgBAk8jQKgmQABo5PSKJxMgVBMgADQ6y8dZQOCJBAjVBAgAbU54nACBpxIgVBMgADRxegUChHICBIAmZ/k4Cwg8mQChmgABoMUJjxMg8HQChGoCBIAGTq/gEwFCNQECQIOzfJwFBBAglBMgALy6Ex4nQIDvCRCqCRAAXpnTK/gxAUI1AQLAKzvLx1lAgE8ECNUECACv6oTHCRDghwQI1QQIAK/I6RX8NAFCNQECwCs6y8dZQIAfEyBUEyAAvJoTHidAgP9PgFBNgADwSpxewS8TIFQTIAC8krN8nAUE+GkChGoCBIBXccLjBAjw8wQI1QQIAK/A6RV8PgFCNQECwCs4y8dZQIBfJkCoJkAA2HbC4wQI8HkECNUECACbnF7BnAChmgABYNNZPs4CAnw+AUI1AQLAlhMeJ0CAGQFCNQECwAanV/DlBAjVBAgAG87ycRYQYE6AUE2AAJB2wuMECPBlBAjVBAgASU6v4OsJEKoJEACSzvJxFhDgywkQqgkQAFJOeJwAAb6OAKGaAAEgwekVvB0BQjUBAkDCWT7OAgJ8PQFCNQECwHs74XECBHgbAoRqAgSA9+T0Ct6eAKGaAAHgPZ3l4ywgwNsRIFQTIAC8lxMeJ0CAtyVAqCZAAHgPTq/g/QgQqgkQAN7DWT7OAgK8PQFCNQGy67e//8PHJwDA5xMgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoAAejgDwvgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQHb5QQEATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2AAMAP/eOf33z4y1//9vENXpMAoZoAAYBPvv3uPx/++Kc/f/j3t999/ILXJECoJkAA4JOzfJwFBF6ZAKGaAAGA753wOAECr06AUE2AAIDTK7oIEKoJEABwekUXAUI1AQLA053wOAECLQQI1QQIAE/m9IpGAoRqAgSAJzvLx1lAoIkAoZoAAeCpTnicAIE2AoRqAgSAJ3J6RTMBQjUBAsATneXjLCDQSIBQTYAA8DQnPE6AQCsBQjUBAsCTOL3iDgQI1QQIAE9ylo+zgEAzAUI1AQLAU5zwOAEC7QQI1QQIAE/g9Io7ESBUEyAAPMFZPs4CAncgQKgmQAC4uxMeJ0DgLgQI1QQIAHfm9Io7EiBUEyAA3NlZPs4CAnciQKgmQAC4qxMeJ0DgbgQI1QQIAHfk9Io7EyBUEyAA3NFZPs4CAnckQKgmQAC4mxMeJ0DgrgQI1QQIAHfi9IonECBUEyAA3MlZPs4CAncmQKgmQAC4ixMeJ0Dg7gQI1QQIAHfg9IonESBUEyAA3MFZPs4CAk8gQKgmQABod8LjBAg8hQChmgABoJnTK55IgFBNgADQ7CwfZwGBJxEgVBMgALQ64XECBJ5GgFBNgADQyOkVTyZAqCZAAGh0lo+zgMATCRCqCRAA2pzwOAECTyVAqCZAAGji9AoECOUECABNzvJxFhB4MgFCNQECQIsTHidA4OkECNUECAANnF7BJwKEagIEgAZn+TgLCCBAKCdAAHh1JzxOgADfEyBUEyAAvDKnV/BjAoRqAgSAV3aWj7OAAJ8IEKoJEABe1QmPEyDADwkQqgkQAF6R0yv4aQKEagIEgFd0lo+zgAA/JkCoJkAAeDUnPE6AAP+fAKGaAAHglTi9gl8mQKgmQAB4JWf5OAsI8NMECNUECACv4oTHCRDg5wkQqgkQAF6B0yv4fAKEagIEgFdwlo+zgAC/TIBQTYAAsO2ExwkQ4PMIEKoJEAA2Ob2COQFCNQECwKazfJwFBPh8AoRqAgSALSc8ToAAMwKEagIEgA1Or+DLCRCqCRAANpzl4ywgwJwAoZoAASDthMcJEODLCBCqCRAAkpxewdcTIFQTIAAkneXjLCDAlxMgVBMgAKSc8DgBAnwdAUI1AQJAgtMreDsChGoCBICEs3ycBQT4egKEagIEgPd2wuMECPA2BAjVBAgA78npFbw9AUI1AQLAezrLx1lAgLcjQKgmQAB4Lyc8ToAAb0uAUE2AAPAenF7B+xEgVBMgALyHs3ycBQR4ewIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQ8z+eRRKVU31XYwAAAABJRU5ErkJggg==";

// src/brand.ts
var BRAND_NAME = "ENDEKS HABER";
var COLORS = { navy: "#112333", paper: "#E4E9EC", steel: "#8095A4" };
var MARK_PATH = "M88 74 H316 L292 110 H136 V172 H270 V208 H136 V270 H316 L292 306 H88 Z";

// src/report-card.ts
var esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
function reportCard(d) {
  if (d.card_data.report.general) return generalCard(d.card_data.report.general);
  const data = d.card_data.report, rows = data.rows.slice(0, 30), cols = rows.length > 15 ? 2 : 1, height = Math.min(65, 850 / Math.ceil(Math.max(1, rows.length) / cols));
  const text = (s, x, y, size, color = COLORS.paper) => `<text x="${x}" y="${y}" font-size="${size}" fill="${color}">${esc(s)}</text>`;
  let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350"><rect width="1080" height="1350" fill="${COLORS.navy}"/><g font-family="Noto Sans, sans-serif"><image href="${PROFILE_DATA}" x="64" y="52" width="64" height="64"/>` + text("ENDEKS HABER", 148, 94, 30) + text(d.headline.replace(/^📢\s*/, ""), 64, 210, 40) + text(d.body, 64, 263, 26, COLORS.steel);
  for (let c = 0; c < cols; c++) {
    const x = 64 + c * 500;
    svg += text("H\u0130SSE", x, 310, 20, COLORS.steel) + text(d.headline.includes("Devre") ? "B\u0130LD\u0130R\u0130M / ENDEKS" : "ALIM M\u0130KTARI", x + (cols === 2 ? 145 : 440), 310, 20, COLORS.steel);
  }
  rows.forEach((r, i) => {
    const col = i % cols, line2 = Math.floor(i / cols), x = 64 + col * 500, y = 350 + line2 * height;
    svg += text(r.label, x, y, cols === 2 ? 25 : 31) + text(r.value, x + (cols === 2 ? 145 : 440), y, cols === 2 ? 20 : 30);
  });
  if (!rows.length) svg += text("Do\u011Frulanm\u0131\u015F g\xFCnl\xFCk i\u015Flem sat\u0131r\u0131 yok.", 64, 380, 32);
  if (data.rows.length > rows.length) svg += text(`Di\u011Fer ${data.rows.length - rows.length} hisse rapor say\u0131m\u0131na dahildir.`, 64, 1180, 22, COLORS.steel);
  const words = data.footer.split(" "), lines = [];
  let line = "";
  for (const w of words) {
    if ((line + " " + w).length > 73) {
      lines.push(line);
      line = w;
    } else line += (line ? " " : "") + w;
  }
  if (line) lines.push(line);
  lines.forEach((s, i) => svg += text(s, 64, 1260 + i * 30, 21, COLORS.steel));
  return svg + "</g></svg>";
}
function generalCard(g) {
  const cols = g.rows.length > 45 ? 3 : g.rows.length > 15 ? 2 : 1, per = Math.ceil(g.rows.length / cols), width = cols * 1060 + 120, scale = width / 2200;
  const rowHeight = g.rows.length > 100 ? 52 : g.rows.length > 45 ? 58 : 64, headerHeight = 420 * scale, top = headerHeight + 105, height = Math.ceil(Math.max(1100, top + per * rowHeight + 150));
  const t = (s, x, y, size, color = COLORS.navy, anchor = "start") => `<text x="${x}" y="${y}" text-anchor="${anchor}" font-size="${size}" fill="${color}">${esc(s)}</text>`;
  let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><rect width="100%" height="100%" fill="#FFFFFF"/><g font-family="Noto Sans, sans-serif"><g transform="scale(${scale})"><image href="${PROFILE_DATA}" x="60" y="42" width="100" height="100"/><g font-weight="700">` + t("ENDEKS HABER", 190, 116, 58) + t("PAY GER\u0130 ALIMLARI", 60, 260, 96) + "</g>" + t(g.day + " \u2022 " + g.time + " itibar\u0131yla", 60, 314, 34);
  const metrics = [["H\u0130SSE", String(g.companies)], ["TOPLAM LOT", g.lots], ["TOPLAM TUTAR" + (g.missing ? " (KISM\u0130)" : ""), g.amount + " TL"]];
  metrics.forEach(([label, value], i) => {
    const x = 60 + i * 2080 / 3;
    svg += t(label, x, 375, 25) + t(value, x, 426, 40);
  });
  svg += "</g>";
  const font = g.rows.length > 100 ? 26 : 28;
  for (let c = 0; c < cols; c++) {
    const x = 60 + c * 1060, y = headerHeight + 55;
    svg += `<g font-weight="700">` + t("H\u0130SSE", x, y, 24) + t("LOT", x + 420, y, 24, COLORS.navy, "end") + t("ORT. F\u0130YAT (TL)", x + 690, y, 24, COLORS.navy, "end") + t("TUTAR (TL)", x + 1e3, y, 24, COLORS.navy, "end") + "</g>";
  }
  g.rows.forEach((r, i) => {
    const c = Math.floor(i / Math.max(1, per)), line = i % Math.max(1, per), x = 60 + c * 1060, y = top + line * rowHeight;
    svg += `<rect x="${x - 12}" y="${y - 35}" width="1030" height="${rowHeight - 4}" fill="${COLORS.navy}" opacity="${line % 2 ? ".025" : ".065"}"/>` + t("#" + r.ticker, x, y, font + 2) + t(r.lots, x + 420, y, font, COLORS.navy, "end") + t(r.price, x + 690, y, font, COLORS.navy, "end") + t(r.amount, x + 1e3, y, font, COLORS.navy, "end");
  });
  if (!g.rows.length) svg += t("Do\u011Frulanm\u0131\u015F g\xFCnl\xFCk i\u015Flem sat\u0131r\u0131 yok.", 60, top, 32);
  svg += t("Yaln\u0131z KAP pay geri al\u0131m\u0131 bildirimleri esas al\u0131nm\u0131\u015Ft\u0131r. Farkl\u0131l\u0131k g\xF6sterebilir.", 60, height - 82, 24) + t(g.missing ? "Eksik fiyatlar \u2014 ile g\xF6sterilir. Toplam tutar k\u0131smi olabilir." : "Ortalama fiyat lot a\u011F\u0131rl\u0131kl\u0131d\u0131r. Tutar i\u015Flem sat\u0131rlar\u0131ndan hesaplanm\u0131\u015Ft\u0131r.", 60, height - 40, 24);
  return svg + "</g></svg>";
}

// src/akd-columns.ts
function akdColumns(row) {
  const number = "[-+\u2212]?\\d+(?:[.,]\\d+)*";
  const parts = row.value.split(/[·|;]/).map((v) => v.trim());
  if (parts.length >= 2 && parts.length <= 3) {
    const ratio = parts[0].match(new RegExp(`^(%${number}|${number}%)$`, "iu"))?.[1] ?? null;
    const q = parts.find((v) => new RegExp(`^${number}\\s*(?:lot|adet|pay)$`, "iu").test(v));
    const quantity = q?.match(new RegExp(`^(${number})\\s*(lot|adet|pay)$`, "iu"));
    const cost = parts.find((v) => new RegExp(`^${number}(?:\\s*(?:TL|\u20BA))?$`, "iu").test(v) && v !== q && v !== parts[0]) ?? null;
    if (ratio || quantity || cost) return { ratio, quantity: quantity?.[1] ?? null, unit: quantity?.[2].toLocaleLowerCase("tr-TR") ?? null, cost };
  }
  const amount = new RegExp(`^\\s*(${number})\\s*(lot|adet|pay)(?:\\s+net\\s+(?:sat\u0131\u015F|sat\u0131m|al\u0131\u015F|al\u0131m))?\\s*$`, "iu").exec(row.value);
  return amount ? { ratio: null, quantity: amount[1], unit: amount[2].toLocaleLowerCase("tr-TR"), cost: null } : null;
}

// src/card-layout.ts
var CARD_LAYOUTS = ["editorial", "frame", "rail", "masthead", "center", "brief"];

// src/market-card.ts
var esc2 = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
function marketCard(d, theme, layout, fit) {
  if (d.template === "circuit") return circuitCard("navy", "editorial", d.card_data?.tickers ?? []);
  const bg = COLORS[theme], fg = theme === "navy" ? COLORS.paper : COLORS.navy, steel = COLORS.steel;
  const data = d.card_data, variant = CARD_LAYOUTS.indexOf(layout), left = layout === "rail" ? 122 : 76, width = 1080 - left - 76;
  const rect = (x, y, w, h, fill, stroke) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}"${stroke ? ` stroke="${stroke}" stroke-width="2"` : ""}/>`;
  const text = (s, x, y, size, color = fg, weight = 400, anchor = "start") => `<text x="${x}" y="${y}" font-size="${size}" font-weight="${weight}" fill="${color}" text-anchor="${anchor}">${esc2(s.replace(/−/g, "-"))}</text>`;
  const rule = (y) => `<path d="M${left} ${y} H1004" stroke="${steel}" stroke-width="1"/>`;
  const block = (s, x, y, w, h, size = 40, color = fg, min = 26, weight = 400, align2) => fit(s.replace(/−/g, "-"), { x, y, width: w, height: h, size, min, weight, color, align: align2 });
  const labels = { circuit: "DEVRE KES\u0130C\u0130", institutional: data?.buy?.length && !data?.sell?.length ? "KURUM / ALIM" : data?.sell?.length && !data?.buy?.length ? "KURUM / SATIM" : "KURUM ALIM / SATIM", akd: "H\u0130SSE / AKD", volume: "\u0130\u015ELEM HACM\u0130", broker_flow: "ARACI KURUM / NET \u0130\u015ELEM", custody: "TAKAS / SAKLAMA" };
  const inverse = layout === "brief" || layout === "masthead";
  let art = layout === "frame" ? rect(34, 34, 1012, 1282, "none", steel) : layout === "rail" ? rect(0, 0, 38, 1350, fg) + rect(38, 0, 6, 1350, steel) : "";
  if (inverse) art += rect(0, 0, 1080, 180, fg);
  art += `<image x="${left}" y="58" width="68" height="68" href="${PROFILE_DATA}"/>` + text("ENDEKS", left + 90, 88, 30, inverse ? bg : fg, 700) + text("H A B E R", left + 92, 116, 17, steel, 700) + text(labels[d.template], 1004, 102, 22, inverse ? bg : steel, 700, "end");
  art += rule(182);
  if (data?.as_of) art += text(data.as_of, left, 222, 24, steel);
  const centered = layout === "center", align = centered ? "center" : void 0;
  const separateTicker = data?.ticker && !d.headline.includes(data.ticker);
  if (d.template === "volume") {
    art += block(d.headline, left, 276, width, 200, 65, fg, 42, 700, align);
    if (separateTicker) art += text(data.ticker, 1004, 505, 32, steel, 700, "end");
    const hero = data?.metrics?.[0];
    if (hero) {
      art += text(hero.label, left, 557, 27, steel, 700) + block(hero.value, left, 592, width, 180, 114, fg, 60, 700);
    } else art += `<path d="${MARK_PATH}" transform="translate(380 500) scale(.75)" fill="${steel}" opacity=".20"/>`;
    let y = 836;
    for (const row of data?.metrics?.slice(1, 3) ?? []) {
      art += rule(y - 20) + text(row.label, left, y + 16, 27, steel) + text(row.value, 1004, y + 22, 36, fg, 700, "end");
      y += 110;
    }
    art += rule(1110) + block(d.body, left, 1150, width, 150, 32, fg, 26);
  } else if (d.template === "custody") {
    if ((data?.holdings?.length ?? 0) > 5) throw Error("market_card_capacity_custody");
    art += block(d.headline, left, 268, width, 155, 61, fg, 38, 700, align);
    if (separateTicker) art += text(data.ticker, 1004, 455, 32, steel, 700, "end");
    const hero = data?.metrics?.[0];
    if (hero) art += text(hero.label, left, 500, 26, steel, 700) + block(hero.value, left, 530, width, 120, 78, fg, 44, 700);
    if (data?.holdings?.length) {
      art += rect(left, 710, width, 440, fg) + text("SAKLAMA KURULU\u015ELARI", left + 28, 755, 25, bg, 700);
      data.holdings.forEach((r, i) => {
        const y = 778 + i * 70;
        art += block(r.label, left + 28, y, width * 0.4, 60, 29, bg, 20, 700) + block(r.value, left + width * 0.45, y, width * 0.55 - 28, 60, 28, bg, 18);
      });
      art += block(d.body, left, 1190, width, 110, 29, fg, 22);
    } else art += block(d.body, left, 735, width, 430, 45, fg, 28);
  } else if (d.template === "akd" && (data?.buy?.length || data?.sell?.length)) {
    art += block(d.headline, left, 268, width, 155, 61, fg, 38, 700, align);
    if (separateTicker) art += text(data.ticker, 1004, 446, 32, steel, 700, "end");
    const table = (title, rows, y, invert) => {
      if (!rows?.length) return "";
      if (rows.length > 5) throw Error("market_card_capacity_akd");
      const ink = invert ? bg : fg, muted = invert ? bg : steel, parsed = rows.map(akdColumns), structured = parsed.every(Boolean);
      const units = new Set(parsed.flatMap((p) => p?.unit ? [p.unit] : [])), unit = units.size === 1 ? [...units][0] : void 0;
      const bounds = structured ? [0, 0.29, 0.46, 0.79, 1] : [0, 0.48, 1];
      const headers = structured ? ["KURUM", "ORAN", unit === "lot" ? "NET LOT" : unit === "adet" ? "NET ADET" : unit === "pay" ? "NET PAY" : "NET M\u0130KTAR"] : ["KURUM", "VER\u0130"];
      if (structured) headers.push("MAL\u0130YET");
      const inner = width - 48, x = left + 24;
      let svg = rect(left, y, width, 365, invert ? fg : bg, invert ? void 0 : steel) + text(title, x, y + 43, 25, muted, 700);
      headers.forEach((h, i) => {
        svg += text(h, x + bounds[i] * inner, y + 83, 20, muted, 700);
      });
      svg += `<path d="M${x} ${y + 96} H${left + width - 24}" stroke="${muted}" stroke-width="1" opacity=".45"/>`;
      rows.forEach((r, i) => {
        const p = parsed[i], values = structured ? [r.label, p?.ratio ?? "\u2014", p?.quantity ? p.unit ? `${p.quantity} ${unit || p.unit}` : p.quantity : "\u2014", p?.cost ?? "\u2014"] : [r.label, r.value];
        values.forEach((v, j) => {
          svg += block(v, x + bounds[j] * inner, y + 110 + i * 49, (bounds[j + 1] - bounds[j]) * inner - 12, 48, j === 0 ? 27 : 25, ink, j === 0 ? 18 : 17, j === 0 ? 700 : 400);
        });
      });
      return svg;
    };
    art += table("ALICI KURUMLAR", data.buy, 480, layout !== "masthead") + table("SATICI KURUMLAR", data.sell, 860, layout === "masthead");
  } else if (d.template === "broker_flow" && (data?.buy?.length || data?.sell?.length)) {
    art += block(d.headline, left, 268, width, 155, 61, fg, 38, 700, align);
    if (separateTicker) art += text(data.ticker, 1004, 446, 32, steel, 700, "end");
    const table = (title, rows, y, invert) => {
      if (!rows?.length) return "";
      if (rows.length > 5) throw Error("market_card_capacity_broker_flow");
      const ink = invert ? bg : fg;
      let svg = rect(left, y, width, 310, invert ? fg : bg, invert ? void 0 : steel) + text(title, left + 28, y + 46, 25, invert ? bg : steel, 700);
      rows.forEach((row, i) => {
        const top = y + 69 + i * 46;
        svg += block(row.label, left + 28, top, width - 360, 46, 30, ink, 18, 700) + block(row.value, 1004 - 300, top, 272, 46, 30, ink, 18);
      });
      return svg;
    };
    art += table(d.template === "broker_flow" ? "NET ALICI KURUMLAR" : "ALICI KURUMLAR", data.buy, 480, layout !== "masthead") + table(d.template === "broker_flow" ? "NET SATICI KURUMLAR" : "SATICI KURUMLAR", data.sell, 836, layout === "masthead");
    art += block(d.body, left, 1190, width, 105, 30, fg, 22);
  } else if (d.template === "institutional" && (data?.buy?.length || data?.sell?.length)) {
    art += block(d.headline, left, 268, width, 192, 61, fg, 38, 700, align);
    const both = !!(data.buy?.length && data.sell?.length), gap = 26, col = both ? (width - gap) / 2 : width;
    if ((data.buy?.length ?? 0) > 10 || (data.sell?.length ?? 0) > 10) throw Error("market_card_capacity_institutional");
    const brokerId = (data.broker ?? "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    const brokerLabel = ["BANKOFAMERICA", "BOFA"].includes(brokerId) ? "BofA" : "KURUM";
    const panel = (title, rows, x, invert) => {
      if (!rows?.length) return "";
      const ink = invert ? bg : fg;
      let svg = rect(x, 510, col, 650, invert ? fg : bg, invert ? void 0 : steel) + text(title, x + 22, 558, 22, invert ? bg : steel, 700);
      rows.forEach((r, i) => {
        const y = 590 + i * 54, labelWidth = both ? /^[A-Z][A-Z0-9]{3,4}$/.test(r.label) ? 105 : col * 0.45 : col * 0.35;
        svg += block(r.label, x + 22, y, labelWidth, 48, both ? 29 : 33, ink, 22, 700);
        svg += block(r.value, x + 32 + labelWidth, y, col - labelWidth - 54, 48, both ? 25 : 33, ink, both ? 18 : 23);
      });
      return svg;
    };
    art += panel(`${brokerLabel} \xDCZER\u0130NDEN ALIM`, data.buy, left, layout !== "masthead") + panel(`${brokerLabel} \xDCZER\u0130NDEN SATIM`, data.sell, both ? left + col + gap : left, layout === "masthead");
  } else {
    art += block(d.headline, left, 268, width, 192, 61, fg, 38, 700, align);
    if (data?.ticker) art += text(data.ticker, 1004, 486, 34, fg, 700, "end");
    const gap = 26, col = (width - gap) / 2, start = 535;
    const panel = (title, rows, x, invert) => {
      if (!rows?.length) return "";
      if (rows.length > 5) throw Error("market_card_capacity_market");
      const ink = invert ? bg : fg, paper = invert ? fg : bg;
      let svg = rect(x, start, col, 530, paper, invert ? void 0 : steel) + text(title, x + 25, start + 47, 25, invert ? bg : steel, 700);
      for (let i = 0; i < rows.length; i++) {
        const y = start + 82 + i * 85;
        svg += block(rows[i].label, x + 25, y, col - 50, 38, d.template === "akd" ? 28 : 35, ink, 23, 700);
        svg += block(rows[i].value, x + 25, y + 40, col - 50, 38, 30, ink, 22);
      }
      return svg;
    };
    if (data?.buy?.length || data?.sell?.length) {
      art += panel(d.template === "akd" ? "ALICI KURUMLAR" : "EN \xC7OK ALINAN", data.buy, left, layout !== "masthead");
      art += panel(d.template === "akd" ? "SATICI KURUMLAR" : "EN \xC7OK SATILAN", data.sell, left + col + gap, layout === "masthead");
    } else art += block(d.body, left, 586, width, 420, 48, fg, 32);
    if (data?.buy?.length || data?.sell?.length) art += rule(1120) + block(d.body, left, 1160, width, 150, 31, fg, 25);
  }
  art += `<path d="M${left} 1308 H${left + 56 + variant * 22}" stroke="${steel}" stroke-width="${layout === "brief" ? 7 : 3}"/>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1080" height="1350" viewBox="0 0 1080 1350" role="img"><title>${BRAND_NAME} \u2014 ${esc2(d.headline)}</title>${rect(0, 0, 1080, 1350, bg)}<g font-family="Noto Sans">${art}</g></svg>`;
}
function circuitCard(theme, layout, tickers) {
  if (!Array.isArray(tickers) || tickers.some((c) => typeof c !== "string" || !/^[A-Z][A-Z0-9]{3,4}$/.test(c))) throw Error("invalid_circuit_tickers");
  const codes = [...new Set(tickers)], dense = codes.length > 24;
  const bg = COLORS[theme], ink = theme === "navy" ? COLORS.paper : COLORS.navy, steel = COLORS.steel;
  const centered = layout === "center", x = centered ? 540 : layout === "rail" ? 130 : 80, anchor = centered ? "middle" : "start";
  const panel = layout === "brief" || layout === "masthead", fg = panel ? bg : ink;
  const frame = layout === "frame" ? `<rect x="32" y="32" width="1016" height="1286" fill="none" stroke="${steel}" stroke-width="2"/>` : layout === "rail" ? `<rect width="24" height="1350" fill="${ink}"/><rect x="24" width="6" height="1350" fill="${steel}"/>` : "";
  const left = layout === "rail" ? 130 : 80, width = 1e3 - left;
  const y = dense ? 370 : codes.length > 6 ? 450 : layout === "brief" ? 540 : layout === "masthead" ? 570 : centered ? 565 : 550;
  const size = dense ? 86 : codes.length > 6 ? 148 : 174;
  const listTop = dense ? 480 : codes.length > 6 ? 720 : 830, listHeight = 1250 - listTop;
  let grid = "";
  if (codes.length) {
    const tags = codes.map((c) => "#" + c), gap = dense ? 10 : 14;
    let settings;
    for (const font2 of [44, 40, 36, 32, 30, 28, 26, 24, 22]) {
      const cell2 = Math.ceil(Math.max(...tags.map((t) => [...t].reduce((n, c) => n + (/[MW]/.test(c) ? 0.98 : /[IL1]/.test(c) ? 0.4 : 0.75), 0) * font2))) + (dense ? 12 : 28);
      const columns2 = Math.min(codes.length, Math.max(1, Math.floor((width + gap) / (cell2 + gap)))), row2 = Math.ceil(font2 * 1.25) + (dense ? 6 : 16);
      if (Math.ceil(codes.length / columns2) * row2 <= listHeight) {
        settings = { font: font2, cell: cell2, columns: columns2, row: row2 };
        break;
      }
    }
    if (!settings) throw Error("circuit_card_capacity");
    const { font, cell, columns, row } = settings, total = columns * cell + (columns - 1) * gap, start = centered ? left + (width - total) / 2 : left;
    grid = tags.map((tag, i) => {
      const tx = start + i % columns * (cell + gap), ty = listTop + Math.floor(i / columns) * row;
      return `<g data-circuit-ticker="${esc2(codes[i])}"><rect x="${tx}" y="${ty}" width="${cell}" height="${row - 6}" fill="none" stroke="${steel}" stroke-width="1"/><text x="${tx + cell / 2}" y="${ty + (row - 6) / 2 + font * 0.34}" font-size="${font}" font-weight="700" text-anchor="middle" fill="${ink}">${esc2(tag)}</text></g>`;
    }).join("");
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350" role="img"><title>${BRAND_NAME} \u2014 DEVRE KES\u0130C\u0130</title>
 <rect width="1080" height="1350" fill="${bg}"/>${frame}
 <image x="80" y="66" width="76" height="76" href="${PROFILE_DATA}"/>
 <g font-family="Noto Sans"><text x="178" y="103" font-size="36" font-weight="700" fill="${ink}">ENDEKS</text><text x="180" y="136" font-size="20" font-weight="700" letter-spacing="6" fill="${steel}">HABER</text>
 <path d="M80 192 H1000" stroke="${steel}" stroke-width="1"/>
 ${panel ? `<rect x="48" y="${dense ? 246 : codes.length > 6 ? 270 : 310}" width="984" height="${dense ? 180 : codes.length > 6 ? 395 : 470}" fill="${ink}"/>` : ""}
 <path d="M${centered ? 474 : x} ${y - (dense ? 120 : 180)} h132" stroke="${steel}" stroke-width="${dense ? 8 : 12}"/>
 ${dense ? `<text x="${x}" y="${y}" font-size="${size}" font-weight="700" letter-spacing="-2" text-anchor="${anchor}" fill="${fg}">DEVRE KES\u0130C\u0130</text>` : `<text x="${x}" y="${y}" font-size="${size}" font-weight="700" letter-spacing="-5" text-anchor="${anchor}" fill="${fg}">DEVRE</text><text x="${x}" y="${y + size + 22}" font-size="${size}" font-weight="700" letter-spacing="-5" text-anchor="${anchor}" fill="${fg}">KES\u0130C\u0130</text>`}
 ${grid}
 <path d="M80 1300 H1000" stroke="${steel}" stroke-width="1"/><path d="M80 1300 H${240 + CARD_LAYOUTS.indexOf(layout) * 28}" stroke="${ink}" stroke-width="6"/>
 </g></svg>`;
}

// src/card-theme.ts
function legacyTheme(template) {
  return template === "info" || template === "economic_data" || template === "market" ? "paper" : "navy";
}

// src/card.ts
var esc3 = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
var measure = (s, size) => [...s].reduce((n, c) => n + (/[MW@%]/.test(c) ? 0.94 : /[ilıİ.,:;!' ]/.test(c) ? 0.32 : /[A-ZÇĞÖŞÜ0-9]/.test(c) ? 0.69 : 0.59), 0) * size;
function wrap(text, size, width) {
  const words = text.trim().split(/\s+/).filter(Boolean);
  if (words.some((w) => measure(w, size) > width)) throw new Error("card_word_overflow");
  const greedy = [];
  let line = "";
  for (const word of words) {
    const next = line ? line + " " + word : word;
    if (measure(next, size) > width && line) {
      greedy.push(line);
      line = word;
    } else line = next;
  }
  if (line) greedy.push(line);
  if (greedy.length < 2 || greedy.length > 10) return greedy;
  const target = measure(words.join(" "), size) / greedy.length;
  const memo = /* @__PURE__ */ new Map();
  function solve(start, left) {
    if (!left) return start === words.length ? { cost: 0, lines: [] } : null;
    const key = `${start}:${left}`;
    if (memo.has(key)) return memo.get(key);
    let best = null;
    for (let end = start + 1; end <= words.length - left + 1; end++) {
      const value = words.slice(start, end).join(" "), w = measure(value, size);
      if (w > width) break;
      const tail = solve(end, left - 1);
      if (!tail) continue;
      const cost = (w - target) ** 2 + (end - start === 1 && words.length > greedy.length ? width ** 2 * 0.18 : 0) + tail.cost;
      if (!best || cost < best.cost) best = { cost, lines: [value, ...tail.lines] };
    }
    memo.set(key, best);
    return best;
  }
  return solve(0, greedy.length)?.lines ?? greedy;
}
function draftCard(d, sources = [], date = "", demo = false, theme, layout = "editorial") {
  return cardSvg({ headline: d.card_headline, body: d.card_body, template: d.template, card_data: d.card_data }, sources, date, demo, theme, layout);
}
function cardSvg(d, _sources = [], _date = "", _demo = false, theme, layout = "editorial") {
  if (d.card_data?.report) return reportCard(d);
  const headline = d.headline.replace(/^(?:\p{Extended_Pictographic}\uFE0F?\s*)+/u, "").trim();
  if (!headline || !d.body.trim()) throw new Error("card_content_empty");
  if (["circuit", "institutional", "akd", "volume", "broker_flow", "custody"].includes(d.template)) return marketCard({ ...d, headline }, theme ?? legacyTheme(d.template), layout, fitText);
  const label = templateLabel(d.template), special = d.template === "breaking" || d.template === "circuit";
  const dark = (theme ?? legacyTheme(d.template)) === "navy";
  const bg = dark ? COLORS.navy : COLORS.paper, fg = dark ? COLORS.paper : COLORS.navy;
  if (layout !== "editorial") return alternateCard(headline, d.body, special, bg, fg, layout, label);
  const bodySize = 36, bodyLines = wrap(d.body, bodySize, 848);
  if (bodyLines.length > 6) throw new Error("card_content_overflow");
  const bodyHeight = Math.max(290, bodyLines.length * 53 + 114), panelY = 1350 - bodyHeight;
  const top = special ? 310 : 270, bottom = panelY - 90, available = bottom - top;
  const preferredLines = headline.length > 80 ? 5 : headline.length > 64 ? 4 : 3;
  let size = 108, lines = [];
  for (; size >= 60; size -= 2) {
    try {
      lines = wrap(headline, size, 920);
    } catch (e) {
      if (size === 60) throw e;
      continue;
    }
    if (lines.length <= (size === 60 ? 7 : preferredLines) && lines.length * size * 1.14 <= available) break;
  }
  if (size < 60) throw new Error("card_content_overflow");
  const headlineY = top + Math.max(0, (available - lines.length * size * 1.14) * 0.38) + size * 0.86;
  const text = (values, x, y, fontSize, lineHeight, weight, color) => values.map((v, i) => `<text x="${x}" y="${Math.round(y + i * lineHeight)}" font-size="${fontSize}" font-weight="${weight}" fill="${color}">${esc3(v)}</text>`).join("");
  const signature = `<path d="${MARK_PATH}" transform="translate(740 -40) scale(.85)" fill="${COLORS.steel}" opacity=".10"/>`;
  const panelBg = dark ? COLORS.paper : COLORS.navy, panelFg = dark ? COLORS.navy : COLORS.paper;
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1080" height="1350" viewBox="0 0 1080 1350" role="img" aria-labelledby="card-title">
 <title id="card-title">${BRAND_NAME} \u2014 ${esc3(headline)}</title>
 <rect width="1080" height="1350" fill="${bg}"/>
 ${signature}
 <image x="76" y="66" width="80" height="80" xlink:href="${PROFILE_DATA}"/>
 <g font-family="Noto Sans">
 <text x="178" y="107" fill="${fg}" font-size="38" font-weight="700" letter-spacing="1">ENDEKS</text>
 <text x="180" y="139" fill="${COLORS.steel}" font-size="22" font-weight="700" letter-spacing="7">HABER</text>
 <path d="M76 192 H1004" stroke="${COLORS.steel}" stroke-width="1" opacity=".45"/>
 <path d="M76 192 H156" stroke="${fg}" stroke-width="5"/>
 ${special ? `<rect x="76" y="236" width="12" height="12" fill="${COLORS.steel}"/><text x="106" y="251" fill="${fg}" font-size="22" font-weight="700" letter-spacing="3">${esc3(label)}</text>` : ""}
 ${text(lines, 76, headlineY, size, size * 1.14, 700, fg)}
 <rect y="${panelY}" width="1080" height="${bodyHeight}" fill="${panelBg}"/>
 <path d="M76 ${panelY} H192" stroke="${COLORS.steel}" stroke-width="8"/>
 <path d="M76 ${panelY + 64} V${panelY + bodyHeight - 64}" stroke="${COLORS.steel}" stroke-width="2"/>
 ${text(bodyLines, 112, panelY + 88, bodySize, 53, 400, panelFg)}
 </g></svg>`;
}
function templateLabel(template) {
  return { breaking: "SON DAK\u0130KA", circuit: "DEVRE KES\u0130C\u0130", kap: "KAP B\u0130LD\u0130R\u0130M\u0130", company: "\u015E\u0130RKET HABERLER\u0130", market: "BIST / P\u0130YASA", finance: "EKONOM\u0130 / F\u0130NANS", economic_data: "EKONOM\u0130K VER\u0130", global: "K\xDCRESEL P\u0130YASALAR", info: "B\u0130LG\u0130 / \u0130STAT\u0130ST\u0130K", news: "HABER", institutional: "KURUM ALIM / SATIM", akd: "ARACI KURUM DA\u011EILIMI", volume: "\u0130\u015ELEM HACM\u0130", broker_flow: "ARACI KURUM / NET \u0130\u015ELEM", custody: "TAKAS / SAKLAMA" }[template];
}
function fitText(value, b) {
  for (let size = b.size; size >= b.min; size -= 2) {
    let lines;
    try {
      lines = wrap(value, size, b.width);
    } catch {
      continue;
    }
    const leading = size * 1.2;
    if (lines.length * leading > b.height) continue;
    const x = b.align === "center" ? b.x + b.width / 2 : b.x;
    return lines.map((line, i) => `<text x="${x}" y="${Math.round(b.y + size * 0.95 + i * leading)}" font-size="${size}" font-weight="${b.weight}" fill="${b.color}"${b.align === "center" ? ' text-anchor="middle"' : ""}>${esc3(line)}</text>`).join("");
  }
  throw Error("card_content_overflow");
}
function alternateCard(headline, body, breaking, bg, fg, layout, label) {
  const steel = COLORS.steel;
  const rect = (x, y, w, h, fill, stroke) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}"${stroke ? ` stroke="${stroke}" stroke-width="2"` : ""}/>`;
  const line = (x, y, x2, y2, color = steel, width = 2) => `<path d="M${x} ${y} H${x2}" transform="translate(0 0)" stroke="${color}" stroke-width="${width}"/>`;
  const logo = (x, y, color) => `<image x="${x}" y="${y}" width="72" height="72" xlink:href="${PROFILE_DATA}"/><text x="${x + 94}" y="${y + 33}" fill="${color}" font-size="32" font-weight="700" letter-spacing="1">ENDEKS</text><text x="${x + 96}" y="${y + 61}" fill="${steel}" font-size="18" font-weight="700" letter-spacing="6">HABER</text>`;
  let decoration = "", brand = "", head, detail;
  switch (layout) {
    case "frame":
      decoration = rect(40, 40, 1e3, 1270, "none", steel) + rect(76, 918, 928, 356, fg) + line(76, 230, 1004, 230, fg, 4);
      brand = logo(76, 98, fg);
      head = { x: 88, y: breaking ? 340 : 306, width: 904, height: 550, size: 104, min: 56, weight: 700, color: fg };
      detail = { x: 116, y: 970, width: 848, height: 260, size: 38, min: 30, weight: 400, color: bg };
      break;
    case "rail":
      decoration = rect(0, 0, 70, 1350, fg) + rect(70, 0, 10, 1350, steel) + rect(126, 958, 90, 7, fg) + line(126, 1288, 1e3, 1288);
      brand = logo(126, 90, fg);
      head = { x: 126, y: breaking ? 344 : 300, width: 870, height: 580, size: 102, min: 54, weight: 700, color: fg };
      detail = { x: 250, y: 998, width: 746, height: 255, size: 38, min: 30, weight: 400, color: fg };
      break;
    case "masthead":
      decoration = rect(0, 0, 1080, 824, fg) + rect(76, 820, 168, 8, steel) + line(76, 1178, 1004, 1178);
      brand = logo(76, 1218, fg);
      head = { x: 76, y: breaking ? 218 : 160, width: 928, height: 590, size: 108, min: 56, weight: 700, color: bg };
      detail = { x: 76, y: 894, width: 928, height: 244, size: 40, min: 30, weight: 400, color: fg };
      break;
    case "center":
      decoration = line(76, 220, 1004, 220) + line(430, 926, 650, 926, fg, 5) + line(76, 1276, 1004, 1276);
      brand = logo(385, 80, fg);
      head = { x: 88, y: breaking ? 358 : 310, width: 904, height: 545, size: 102, min: 54, weight: 700, color: fg, align: "center" };
      detail = { x: 140, y: 988, width: 800, height: 245, size: 38, min: 30, weight: 400, color: fg, align: "center" };
      break;
    case "brief":
      decoration = rect(0, 0, 1080, 196, fg) + rect(0, 930, 260, 420, steel) + rect(260, 930, 820, 420, fg) + line(76, 854, 1004, 854, steel, 2);
      brand = logo(76, 62, bg);
      head = { x: 76, y: breaking ? 340 : 286, width: 928, height: 510, size: 106, min: 54, weight: 700, color: fg };
      detail = { x: 310, y: 998, width: 694, height: 288, size: 38, min: 28, weight: 400, color: bg };
      break;
  }
  const breakingY = layout === "masthead" ? 102 : layout === "center" ? 286 : 260;
  const breakingColor = layout === "masthead" ? bg : fg;
  const badge = breaking ? `<text x="${layout === "rail" ? 126 : 76}" y="${breakingY}" font-size="22" font-weight="700" letter-spacing="3" fill="${breakingColor}">${esc3(label)}</text>` : "";
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1080" height="1350" viewBox="0 0 1080 1350" role="img"><title>${BRAND_NAME} \u2014 ${esc3(headline)}</title>${rect(0, 0, 1080, 1350, bg)}<g font-family="Noto Sans">${decoration}${brand}${badge}${fitText(headline, head)}${fitText(body, detail)}</g></svg>`;
}
export {
  COLORS,
  cardSvg,
  draftCard,
  templateLabel,
  wrap
};
