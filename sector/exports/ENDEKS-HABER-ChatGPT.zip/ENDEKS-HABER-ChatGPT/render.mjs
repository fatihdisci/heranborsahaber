import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {cardSvg} from './runtime/cards.mjs';
import {initWasm,Resvg} from './runtime/index.mjs';
const base=new URL('./',import.meta.url),input=process.argv[2],output=process.argv[3]??'kart.png';
if(!input)throw Error('Usage: node render.mjs content.json kart.png');
const d=JSON.parse(await readFile(input,'utf8'));
const svg=cardSvg(d,[],'',false,d.theme??'navy',d.layout??'editorial');
await initWasm(await readFile(new URL('runtime/index_bg.wasm',base)));
const fonts=await Promise.all(['Regular','Bold'].map(n=>readFile(new URL('assets/NotoSans-'+n+'.ttf',base))));
const r=new Resvg(svg,{font:{fontBuffers:fonts,defaultFontFamily:'Noto Sans'}});
try{const image=r.render();try{await writeFile(output,image.asPng());await writeFile(output.replace(/\.png$/i,'')+'.svg',svg);}finally{image.free();}}finally{r.free();}
console.log(output);
